import EditableTable from './Components/Table';
import './App.css';

function App() {
  return (
    <div>
      <EditableTable/>
    </div>
  );
}

export default App;
